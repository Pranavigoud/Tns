package p1;

public class Protectedp1 {
    protected void display()
    {
    	System.out.println("protected access specifier");
    }
}
