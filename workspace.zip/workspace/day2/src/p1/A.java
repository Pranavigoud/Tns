package p1;

public class A {
	int a=10;
	static int b=5;
	int display() {
		return 5;
	}
	static int display1()
	{ 
		return 10;
	}
	public static void main(String[] args) {
		int c=7;
	    System.out.println(c);
		A obj= new A();
		
		System.out.println(obj.a);
		
		
		
		System.out.println(A.b);
		
		obj.display();
		
		A .display1();
  }
}