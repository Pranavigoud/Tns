package p1;

public class Private {
	
		private void display9() {
			System.out.println("private access specifier");
		}
		public static void main(String[] args) {
			Private obj= new Private();
			obj.display9();
		}

	}

