package p1;

public class Protected2 extends Protectedp1 {

	public static void main(String[] args) 
	{
		Protected2 obj4 = new Protected2();
		obj4.display();
	}

}
