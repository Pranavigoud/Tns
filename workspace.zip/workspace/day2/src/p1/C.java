package p1;

public class C {

	public static void main(String[] args) {
		
		int c=10;
		System.out.println(c);
		B b1= new B();
		System.out.println(b1.a);
		System.out.println(B.b);
		b1.display2();
		B.display3();
	}
}
		