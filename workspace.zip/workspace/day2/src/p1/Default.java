package p1;

public class Default {
	void display5() {
		System.out.println("session");
	}

	public static void main(String[] args) {
      Default obj6 = new Default();
      obj6.display5();
	}

}
