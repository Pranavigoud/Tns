package p1;

public class Userdefined {
	int a=10;
	static int b=5;
	int display() {
		return 5;
	}
	static int display1()
	{ 
		return 10;
	}
	public static void main(String[] args) {
		int c=7;
	    System.out.println(c);
		Userdefined obj= new Userdefined();
		
		System.out.println(obj.a);
		
		
		
		System.out.println(Userdefined.b);
		
		obj.display();
		
		Userdefined.display1();
  }


}
