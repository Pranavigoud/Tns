package p1;

public class B {
	int a=5;
	static int b=6;
	int display2()
	{
		return 5;
	}
	static void display3() {
	System.out.println("hello");
	}
}
