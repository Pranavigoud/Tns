/**
 * 
 */
/**
 * 
 */
module Samplepgm2 {
}