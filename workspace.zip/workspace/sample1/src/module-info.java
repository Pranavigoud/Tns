/**
 * 
 */
/**
 * 
 */
module sample1 {
}